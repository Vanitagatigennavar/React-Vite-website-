import "./App.css";
import { useEffect } from "react";
import Navbar from "./Components/navbar/navbar";
import Hero from "./Components/hero/Hero";
import OverviewCounter from "./Components/overview-counter/OverviewCounter";
import SecondBelowPage from "./Components/banner/SecondBelowPage";
import SimpleBelowThirdPage from "./Components/simplebelowpage/SimpleBelowThirdPage";
import BlogsFourthPage from "./Components/blogs/BlogsFourthPage";
import FooterDD from "./Components/footer/FooterDD";
import AOS from "aos";
import "aos/dist/aos.css";
function App() {
  useEffect(() => {
    AOS.init({
      offset: 100,
      duration: 500,
      easing: "ease-in-sine",
      delay: 100,
    });
    AOS.refresh();
  }, []);
  return (
    <>
      <Navbar />
      <Hero />
      <OverviewCounter />
      <SecondBelowPage />
      <SecondBelowPage reverse={true} />
      <SimpleBelowThirdPage />
      <BlogsFourthPage />
      <FooterDD />
    </>
  );
}

export default App;
