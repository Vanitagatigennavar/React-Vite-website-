import React from "react";

const SecondBelowPage = ({ reverse }) => {
  return (
    <section className="bg-slate-100 dark:bg-slate-900">
      <div className="container flex flex-col items-center justify-center py-10 md:h[500px]">
        {" "}
        <div className="grid items-center grid-cols-1 gap-4 md:grid-cols-2">
          {/* text container */}
          <div
            data-aos="fade-left"
            data-aos-duration="400"
            data-aos-once="true"
            className={`flex flex-col items-start gap-4 text-left md:items-start md:p-8 md:text-left ${
              reverse ? "md:order-last" : ""
            }`}
          >
            <h1 className="text-2xl md:text-4xl">
              Transforming Ideas into Apps that Dominate Appworld
            </h1>

            <p className="text-sm text-slate-600 dark:text-slate-400">
              We specialize in crafting innovative and trendsetting mobile
              applications that stand out on the Appworld stage. Our dedicated
              team of experts is committed to building apps that not only meet
              but exceed the expectations of our clients. From concept to
              execution, we leverage cutting-edge technologies and creative
              design to ensure your app not only looks great but also performs
              exceptionally well
            </p>
            <div>
              <ul className="flex flex-col gap-2 list-disc list-inside md:gap-4">
                <li className="font-medium">
                  Crafting trendsetting apps that captivate the Appworld.
                  Elevate your digital presence with our innovative solutions.
                </li>
              </ul>
            </div>
            <button className="px-4 py-2 text-sm text-white transition-colors duration-300 border-2 rounded-md border-primary bg-primary hover:bg-primary/80">
              Start Your Journey
            </button>
          </div>
          {/* image container */}
          <div data-aos="fade-left" className={reverse ? "order-1" : ""}>
            <img
              src="https://eww-wp-new.s3.ap-south-1.amazonaws.com/wp-content/uploads/2021/07/22070719/dedicated-on-demand-app-development-company.jpg"
              className="mx-auto w-full p-4 md:max-w-[400px] md:max-h-[500px]"
            ></img>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SecondBelowPage;
