import React from "react";

const BlogCard = ({ Img }) => {
  return (
    <div className="p-4 transition-all duration-500 shadow-lg hover:shadow-xl dark:bg-slate-950 dark:text-white">
      <div className="overflow-hidden">
        {/* Image with hover effects */}
        <img
          src={Img}
          alt="No Image"
          className="mx-auto h-[250px] w-full object-cover transition duration-700 hover:skew-x-2 hover:scale-110"
        />
      </div>
      <div className="flex justify-between pt-2 text-slate-600">
        <p>February 2024</p> <p className="line-clamp-1">By Vanita</p>
      </div>
      <div className="py-3 space-y-2">
        <h1 className="font-bold line-clamp-1">
          How to grow your business ,How To grow your business How To grow your
          business
        </h1>
        <p className="line-clamp-2">
          In the dynamic landscape of business, adopting effective strategies is
          crucial for sustainable growth. Whether you're exploring new markets,
          enhancing customer experiences, or optimizing internal processes, our
          expert team is here to guide you. We leverage innovative solutions and
          industry best practices to ensure your business thrives in today's
          competitive environment.
        </p>
      </div>
    </div>
  );
};

export default BlogCard;
