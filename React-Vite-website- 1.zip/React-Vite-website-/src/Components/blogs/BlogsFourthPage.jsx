import React from "react";
import BlogCard from "./BlogCard";
import Img1 from "../../assets/Images/blogsimages/Blog1image.png";
import Img2 from "../../assets/Images/blogsimages/Blog2image.png";
import Img3 from "../../assets/Images/blogsimages/Blog3image.png";
const Blogs = () => {
  return (
    <div>
      <div className="dark:bg-gray-900"></div>
      <section data-aos="fade-up" className="container py-8 mb-10">
        <h1 className="py-2 pl-2 mb-8 text-3xl font-bold text-center border-l-8">
          Our Latest Blogs
        </h1>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3">
          <BlogCard Img={Img1} />
          <BlogCard Img={Img2} />
          <BlogCard Img={Img3} />
        </div>
      </section>
    </div>
  );
};

export default Blogs;
