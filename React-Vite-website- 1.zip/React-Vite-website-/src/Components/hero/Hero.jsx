import React from "react";
import ResponsivePic from "../../assets/Images/ResponsivePic.svg";
const Hero = () => {
  return (
    <main className="pt-20 bg-gradient-to-r from-violet-950 to-violet-900 dark:bg-violet-950">
      <section className="container flex h-[650px] flex-col items-center justify-center md:h-[500px] ">
        <div className="grid items-center grid-cols-1 gap-8 dark:text-white md:grid-cols-2">
          <div
            data-aos="fade-right"
            data-aos-duration="400"
            data-aos-once="true"
            className="flex flex-col items-center gap-4 text-center text-white md:items-start md:text-left "
          >
            <h1 className="text-3xl">
              We Build Apps That Get Trending On Appworld
            </h1>
            <p className="">
              we understand the dynamic nature of the app market and strive to
              create solutions that resonate with users and get noticed. Whether
              you're launching a new app or looking to revamp an existing one,
              we have the expertise to bring your vision to life.
            </p>
            <div className="space-x-4">
              <button className="px-4 py-2 text-sm text-white transition-colors duration-300 border-2 rounded-md border-primary bg-primary hover:bg-primary/80">
                Get Started
              </button>
              <button className="px-4 py-2 text-sm text-white transition-colors duration-300 border-2 border-white rounded-md border-1 ">
                Log in{" "}
              </button>
            </div>
          </div>
          <div
            data-aos="fade-left"
            data-aos-duration="400"
            data-aos-once="true"
            className="max-w-xs p-4 mx-auto"
          >
            <img
              src={ResponsivePic}
              alt="No image"
              className="hover:drop-shadow-md"
            />
          </div>
        </div>
      </section>
    </main>
  );
};

export default Hero;
