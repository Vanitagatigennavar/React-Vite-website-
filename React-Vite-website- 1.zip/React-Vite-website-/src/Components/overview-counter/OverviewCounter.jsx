import React from "react";
import CountUp from "react-countup";
const OverviewCounter = () => {
  return (
    <section className="container h-12 p-3 md:h-32">
      <div
        className="grid w-full grid-cols-4 mx-auto bg-white -translate-y-20 md:-translate-y-12 divide-x divide-slate-700 dark:bg-gray-800 dark:text-white/70 md:
      max-w[800] shadow-lg my-4 md:p-5"
      >
        <div className="flex flex-col items-center justify-center">
          <h1 className="text-sm font-bold text-black/80 dar:text-white sm:text-lg md:text-3xl">
            {" "}
            <CountUp end={235} suffix="+" duration={2.75} />
          </h1>
          <h1 className="text-xs sm:text-md md:text-lg">Clients</h1>
        </div>
        <div className="flex flex-col items-center justify-center">
          <h1 className="text-sm font-bold text-black/80 dar:text-white sm:text-lg md:text-3xl">
            {" "}
            <CountUp end={56} suffix="+" duration={2.75} />
          </h1>
          <h1 className="text-xs sm:text-md md:text-lg">Projects</h1>
        </div>
        <div className="flex flex-col items-center justify-center">
          <h1 className="text-sm font-bold text-black/80 dar:text-white sm:text-lg md:text-3xl">
            {" "}
            <CountUp end={234} suffix="+" duration={2.75} />
          </h1>
          <h1 className="text-xs sm:text-md md:text-lg">Subscribers</h1>
        </div>
        <div className="flex flex-col items-center justify-center">
          <h1 className="text-sm font-bold text-black/80 dar:text-white sm:text-lg md:text-3xl">
            {" "}
            <CountUp end={160527} suffix="+" duration={2.75} />
          </h1>
          <h1 className="text-xs sm:text-md md:text-lg">Clients</h1>
        </div>
      </div>
    </section>
  );
};

export default OverviewCounter;
