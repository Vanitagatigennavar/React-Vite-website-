import React from "react";

const SimpleBelowPage = () => {
  return (
    <>
      <div className="bg-violet-800">
        <div data-aos="fade-up" className="container py-8 md:py-12 ">
          <div className="grid items-center grid-cols-1 gap-4 md:grid-cols-3 md:gap-8">
            <div className="px-2">
              <iframe
                className="w-full aspect-video"
                src="https://www.youtube.com/embed/gRWMen27Uio?si=VtHMh9xCxQ6ccFh8"
                title="Youtube video player"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
              ></iframe>
            </div>

            <div className="flex flex-col items-center gap-4 text-center text-white dark:text-white md:col-span-2 md:items-start md:text-left">
              <h1 className="text-3xl font-bold">
                Market Your Next Project with Deal Dox{" "}
              </h1>
              <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit.
                Provident, non veritatis adipisci impedit nihil quidem
                accusantium soluta nulla autem doloribus iste harum inventore
                repudiandae perferendis aliquam at ullam ad quisquam.
              </p>
              <button className="px-4 py-2 text-sm transition-colors duration-300 border-2 rounded-md border-primary hover:bg-primary/80 !bg-white !text-black">
                Get Started
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default SimpleBelowPage;
