import React from "react";
import {
  FaFacebook,
  FaInstagram,
  FaLinkedin,
  FaLocationArrow,
  FaMobileAlt,
} from "react-icons/fa";
import FooterLinksDD from "./FooterLinksDD";

const FooterDD = () => {
  const importantLinks = [
    {
      name: "Home",
    },
    {
      name: "About",
    },
    {
      name: "Service",
    },
    {
      name: "Login",
    },
  ];
  const Links = [
    {
      name: "Privacy Policy",
    },
    {
      name: "Services",
    },
    {
      name: "About us",
    },
  ];
  return (
    <div className="text-white rounded-t-3xl bg-gradient-to-r from-violet-950 to to-violet-950">
      <section className="mx-auto max-w-[1200px] text-white">
        {/* Footer Container section */}
        <div className="grid py-5 md:grid-cols-3">
          <div className="px-3 py-8">
            <h1 className="mb-3 text-xl font-bold text-justify sm:text-left sm:text-3xl">
              <a href="#home" className="">
                DEAL{" "}
                <span className="inline-block font-bold text-primary">DOX</span>
              </a>
            </h1>
            <p className="">
              DealDox is a pioneering platform revolutionizing deal-making
              processes, providing secure and efficient solutions for document
              management and collaboration in the business landscape.
            </p>{" "}
            <br />
            <div className="flex items-center gap-3">
              <FaLocationArrow />
              <p>Karnataka,India</p>{" "}
            </div>
            <div className="flex items-center gap-3 mt-3">
              <FaMobileAlt />
              <p>+91 123456789</p>
            </div>
          </div>
          <div className="grid grid-cols-2 col-span-2 sm:grid-cols-3 md:pl-10">
            <div className="px-4 py-8">
              <h1 className="mb-3 text-xl font-bold text-justify sm:text-left sm:text-xl">
                Important Links
              </h1>
              <ul className="flex flex-col gap-3">
                <FooterLinksDD links={importantLinks} />
              </ul>
            </div>
            <div className="px-4 py-8">
              <h1 className="mb-3 text-xl font-bold text-justify sm:text-left sm:text-xl">
                Links
              </h1>
              <ul className="flex flex-col gap-3">
                <FooterLinksDD links={Links} />
              </ul>
            </div>
            <div className="px-4 py-8">
              <h1 className="mb-3 text-xl font-bold text-justify sm:text-left sm:text-xl">
                Social Links
              </h1>
              <div className="flex flex-col gap-3">
                <h1>Subscribe to our DealDox</h1>
                <input
                  type="text"
                  placeholder="Enter your email"
                  className="px-3 py-1 text-black rounded-full focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500"
                ></input>
                <div className="flex items-center gap-3 mt-6">
                  <a href="#" className="duration-200 hover:scale-105">
                    <FaInstagram className="text-3xl" />{" "}
                  </a>
                  <a href="#" className="duration-200 hover:scale-105">
                    <FaFacebook className="text-3xl" />
                  </a>
                  <a href="#" className="duration-200 hover:scale-105">
                    <FaLinkedin className="text-3xl" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="bottom-footer">
          <p className="py-6 text-center border-t-2 border-gray-300/50">
            Copyright @ 2024.All rights reserved.
          </p>
        </div>
      </section>
    </div>
  );
};

export default FooterDD;
