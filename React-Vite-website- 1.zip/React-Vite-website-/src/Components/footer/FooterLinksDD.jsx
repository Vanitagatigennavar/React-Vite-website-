import React from "react";

const FooterLinksDD = ({ links }) => {
  console.log("Footer Links ", links);
  return (
    <div>
      {links.map((link) => (
        <li
          key={link.name}
          className="cursor-pointer transition-all duration-300 hover:translate-x-[2px]"
        >
          <a href="">{link.name}</a>
        </li>
      ))}
    </div>
  );
};

export default FooterLinksDD;
